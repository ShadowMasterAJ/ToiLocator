/// This enumeration stores the toilet types
enum ToiletType { MALE, FEMALE, DISABLED, NURSING }

///  This is the entity class for the map that we display on our main app._auth
///  Map will be taken from external API
///The arraylist of user accounts which allows the users to check the number of user accounts and the entire arraylist
class UserList {
  User userArray: ArrayList<Users>;
  int numOfUser;

  void getUserList(){}
  int getNumofUsers(){
    return numOfUser;
  }
}

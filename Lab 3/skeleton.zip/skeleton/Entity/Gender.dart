/// enum for Gender

enum Gender { MALE, FEMALE }

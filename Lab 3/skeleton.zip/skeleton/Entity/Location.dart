/// This is the entity class for the location of the mobile phone.
/// Geospatial data will be in the datatype of tuple<double> (x, y)
/// x denotes longitude, y denotes latitude

import 'package:flutter/gestures.dart';

///

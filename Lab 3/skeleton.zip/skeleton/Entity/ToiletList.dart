///The arraylist of toilets which allows the users to check the number of toilets and the entire arraylist
class ToiletList {
  Toilet toiletArray: ArrayList<Toilet>;
  int numOfToilet;

  void getToiletList(){}
  int getNumofToilets(){
    return numOfToilet;
  }
}

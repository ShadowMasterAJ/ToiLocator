///The arraylist of reviews which allows the users to check the number of reviews and the entire arraylist
class ReviewList {
  Review reviewArray: ArrayList<Review>;
  int numOfReview;

  void getReviewList(){}
  int getNumofReviews(){
    return numOfReview;
  }
}
